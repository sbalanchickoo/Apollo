﻿using DP.MDM.UI.MVC.Models;
using System.Collections.Generic;

namespace DP.MDM.UI.MVC.Interfaces
{
    public interface IAllocation
    {
        IEnumerable<Allocation> GetAllocations();

        Allocation GetAllocationByFundInstrument(int fundId, int instrumentId);

        Allocation GetAllocationByAllocationId(int allocationId);

        Allocation Add(Allocation allocation);
    }
}
