﻿using DP.MDM.UI.MVC.Interfaces;
using DP.MDM.UI.MVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DP.MDM.UI.MVC.Repositories
{
    public class AllocationStaticRepo : IAllocation
    {
        private List<Allocation> _allocations = new List<Allocation>()
        {
            new Allocation{Id = 1, AllocationId = 1, FundId = 1, InstrumentId = 100, FxRate = 1.1m, LastModifiedUser = "John", LastModifiedDate = Convert.ToDateTime("2000-01-01")},
            new Allocation{Id = 2, AllocationId = 2, FundId = 2, InstrumentId = 101, FxRate = 1.2m, LastModifiedUser = "John", LastModifiedDate = Convert.ToDateTime("2000-01-01")},
            new Allocation{Id = 3, AllocationId = 3, FundId = 3, InstrumentId = 103, FxRate = 1.3m, LastModifiedUser = "John", LastModifiedDate = Convert.ToDateTime("2000-01-01")}
        };

        public Allocation GetAllocationByAllocationId(int allocationId)
        {
            Allocation allocation = _allocations.Where(a => a.AllocationId == allocationId).OrderByDescending(a => a.LastModifiedDate).FirstOrDefault();
            return allocation;
        }

        public Allocation GetAllocationByFundInstrument(int fundId, int instrumentId)
        {
            Allocation allocation = _allocations.OrderByDescending(a => a.LastModifiedDate).FirstOrDefault(a => a.FundId == fundId && a.InstrumentId == instrumentId);
            return allocation;
        }

        public IEnumerable<Allocation> GetAllocations()
        {
            return _allocations.OrderBy(a => a.FundId);
        }

        public Allocation Add(Allocation allocation)
        {
            int id = _allocations.Max(a => a.Id) + 1;
            Allocation newAllocation = new Allocation
            {
                Id = id,
                AllocationId = allocation.AllocationId,
                FundId = allocation.FundId,
                InstrumentId = allocation.InstrumentId,
                FxRate = allocation.FxRate,
                LastModifiedUser = allocation.LastModifiedUser,
                LastModifiedDate = allocation.LastModifiedDate
            };
            _allocations.Add(newAllocation);
            return newAllocation;
        }
    }
}
