﻿using DP.MDM.UI.MVC.Models;
using System.Collections.Generic;

namespace DP.MDM.UI.MVC.ViewModels
{
    public class AllocationViewModel
    {
        public IEnumerable<Allocation> Allocations { get; set; }
    }
}
