﻿using System;

namespace DP.MDM.UI.MVC.ViewModels
{
    public class AllocationDetailViewModel
    {
        public int Id { get; set; }

        public int AllocationId { get; set; }

        public int FundId { get; set; }

        public int InstrumentId { get; set; }

        public decimal FxRate { get; set; }

        public string LastModifiedUser { get; set; }

        public DateTime LastModifiedDate { get; set; }
    }
}
