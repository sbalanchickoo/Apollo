﻿using DP.MDM.UI.MVC.Interfaces;
using DP.MDM.UI.MVC.Models;
using DP.MDM.UI.MVC.ViewModels;
using Microsoft.AspNetCore.Mvc;
using System;

namespace DP.MDM.UI.MVC.Controllers
{
    [Route("[controller]/[action]")]
    [Route("")]
    public class AllocationManagementController : Controller
    {
        private IAllocation _allocation { get; set; }

        public AllocationManagementController(IAllocation allocation)
        {
            _allocation = allocation;
        }

        [Route("")]
        public IActionResult GetAllocations()
        {
            AllocationViewModel viewModel = new AllocationViewModel();
            viewModel.Allocations = _allocation.GetAllocations();
            return View(viewModel);
        }

        //[Route("{fundId?}/{instrumentId?}")]
        //public IActionResult GetAllocationByFundInstrument(int fundId, int instrumentId)
        //{
        //    AllocationDetailViewModel viewModel = new AllocationDetailViewModel();
        //    Allocation allocation = _allocation.GetAllocationByFundInstrument(fundId, instrumentId);
        //    if (!(allocation == null))
        //    {
        //        viewModel.Allocation = allocation;
        //        return View(viewModel);
        //    }
        //    else
        //    {
        //        return RedirectToAction(nameof(GetAllocations));
        //    }
        //}

        [Route("{id?}")]
        public IActionResult GetAllocationByAllocationId(int id)
        {
            AllocationDetailViewModel viewModel = new AllocationDetailViewModel();
            Allocation allocation = _allocation.GetAllocationByAllocationId(id);
            //if (!(allocation == null))
            //{
            viewModel.Id = allocation.Id;
            viewModel.AllocationId = allocation.AllocationId;
                viewModel.FundId = allocation.FundId;
                viewModel.InstrumentId = allocation.InstrumentId;
                viewModel.FxRate = allocation.FxRate;
            viewModel.LastModifiedUser = allocation.LastModifiedUser;
            viewModel.LastModifiedDate = allocation.LastModifiedDate;
                return View(viewModel);
            //}
            //else
            //{
            //    return RedirectToAction(nameof(GetAllocations));
            //}
        }

        [HttpGet]
        public IActionResult Edit()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(AllocationDetailViewModel model)
        {
            //if (ModelState.IsValid)
            //{
                Allocation newAllocation = new Allocation
                {
                    AllocationId = model.AllocationId,
                    FundId = model.FundId,
                    InstrumentId = model.InstrumentId,
                    FxRate = model.FxRate,
                    LastModifiedDate = DateTime.Now,
                    LastModifiedUser = User.ToString()
                };
                newAllocation = _allocation.Add(newAllocation);
                return RedirectToAction(nameof(GetAllocationByAllocationId), new { id = newAllocation.Id });
            //}
            //else
            //{
            //    return View();
            //}
        }
    }
}